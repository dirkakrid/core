#!/bin/bash

#### Run to uninstallweb_setup ########

sudo rm /usr/bin/send_notification.sh
sudo rm /var/www/index.php
sudo rm -r /var/www/Images

